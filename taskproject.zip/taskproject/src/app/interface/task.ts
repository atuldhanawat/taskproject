export interface Task {
    text?;
    isGlobal?;
    isLeader?;
    creator?;
    isCompleted?;
    start?;
    end?;
}
